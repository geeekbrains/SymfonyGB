<?php

return array (
  'SLACK_WEBHOOK_URL' => NULL,
);
